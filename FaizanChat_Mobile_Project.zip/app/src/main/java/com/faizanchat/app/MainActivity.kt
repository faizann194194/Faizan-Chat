package com.faizanchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF087F5B)
private val Pale = Color(0xFFF4F7F5)

data class ChatContact(val name: String, val preview: String, val time: String, val initial: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FaizanChatApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaizanChatApp() {
    val contacts = remember {
        listOf(
            ChatContact("Ali", "السلام علیکم! کیسے ہو؟", "10:42", "ع"),
            ChatContact("Ahmed", "ٹھیک ہے، شکریہ", "09:18", "ا"),
            ChatContact("Family Group", "آج سب گھر آ رہے ہیں", "کل", "ف"),
            ChatContact("Usman", "تصویر بھیج دینا", "منگل", "ع"),
            ChatContact("Hassan", "اچھا بھائی", "پیر", "ح")
        )
    }
    var selected by remember { mutableStateOf<ChatContact?>(null) }
    var search by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Pale)) {
        if (selected == null) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("Faizan Chat", fontWeight = FontWeight.Bold)
                                Text("سادہ چیٹ ڈیمو", fontSize = 12.sp)
                            }
                        },
                        actions = {
                            IconButton(onClick = { }) {
                                Icon(Icons.Default.Search, contentDescription = "Search")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                    )
                },
                floatingActionButton = {
                    FloatingActionButton(onClick = { selected = contacts.first() }, containerColor = Green) {
                        Icon(Icons.Default.Chat, contentDescription = "New chat", tint = Color.White)
                    }
                },
                containerColor = Pale
            ) { padding ->
                Column(Modifier.padding(padding).fillMaxSize()) {
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        placeholder = { Text("چیٹ تلاش کریں") },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp)
                    )
                    LazyColumn {
                        items(contacts.filter { it.name.contains(search, ignoreCase = true) }) { contact ->
                            Row(
                                Modifier.fillMaxWidth().clickable { selected = contact }.padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(52.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
                                    Text(contact.initial, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(contact.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                                    Text(contact.preview, color = Color.Gray, fontSize = 14.sp, maxLines = 1)
                                }
                                Text(contact.time, color = Color.Gray, fontSize = 12.sp)
                            }
                            HorizontalDivider(color = Color(0xFFE6EAE7))
                        }
                    }
                }
            }
        } else {
            ChatScreen(contact = selected!!, onBack = { selected = null })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(contact: ChatContact, onBack: () -> Unit) {
    val messages = remember(contact.name) { mutableStateListOf("السلام علیکم", "وعلیکم السلام! کیسے ہیں؟") }
    var draft by remember { mutableStateOf("") }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(contact.name, fontWeight = FontWeight.SemiBold)
                        Text("نمونہ چیٹ — انٹرنیٹ سے منسلک نہیں", fontSize = 11.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = { }) { Icon(Icons.Default.Call, contentDescription = "Audio call") }
                    IconButton(onClick = { }) { Icon(Icons.Default.Videocam, contentDescription = "Video call") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Pale,
        bottomBar = {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("پیغام لکھیں") },
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = {
                    if (draft.isNotBlank()) {
                        messages.add(draft.trim())
                        draft = ""
                    }
                }, modifier = Modifier.background(Green, CircleShape)) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    "یہ صرف آزمائشی نمونہ ہے۔ پیغامات اسی فون پر دکھتے ہیں، دوسرے شخص کو نہیں جاتے۔",
                    color = Color.DarkGray, fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
            }
            items(messages) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(
                        message,
                        modifier = Modifier.background(Color(0xFFD8F5E7), RoundedCornerShape(16.dp)).padding(12.dp),
                        color = Color(0xFF173B2E)
                    )
                }
            }
        }
    }
}
